﻿using ASpNET_CORE_WebAPIDemo.Models;
using ASpNET_CORE_WebAPIDemo.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ASpNET_CORE_WebAPIDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployesController : ControllerBase
    {
        IEmployeeService _employeeService;
        public EmployesController(IEmployeeService service)
        {
                _employeeService = service;
        }
        [HttpGet]
        [Route("[action]")]
        public IActionResult GetAllEmployees()
        {
            try
            {
                var employees =  _employeeService.GetEmployeesList();
                if (employees == null) return NotFound();
                return Ok(employees);
            }
            
            catch (System.Exception)
            {

                return BadRequest();
            }
            
        }

        [HttpGet]
        [Route("[action]/id")]
        public IActionResult GetEmployeeById( int id)
        {
            try
            {
                var employees = _employeeService.GetEmployee(id);
                if ( employees == null) return NotFound();
                return Ok(employees);
            }
            catch (System.Exception)
            {

                return BadRequest();
            }
        }
        
    }
}
