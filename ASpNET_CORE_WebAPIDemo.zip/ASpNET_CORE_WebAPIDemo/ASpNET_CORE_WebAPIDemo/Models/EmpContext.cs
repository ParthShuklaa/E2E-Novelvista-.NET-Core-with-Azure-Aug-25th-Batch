﻿using Microsoft.EntityFrameworkCore;

namespace ASpNET_CORE_WebAPIDemo.Models
{
    public class EmpContext : DbContext
        {
        public EmpContext( DbContextOptions options ): base( options )
        {

        }
        DbSet <Employee> Employees { get; set; }
    }
}
