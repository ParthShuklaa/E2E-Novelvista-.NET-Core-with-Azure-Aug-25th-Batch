﻿using System.ComponentModel.DataAnnotations;

namespace ASpNET_CORE_WebAPIDemo.Models
{
    public class Employee
    {
        [Key]
        public int EmployeeId { get; set; }
        public string EmployeeFName { get; set; }
        public string EmployeeLName { get; set; }
        public decimal Salary { get; set; }
        public string Designation { get; set; }


    }
}
