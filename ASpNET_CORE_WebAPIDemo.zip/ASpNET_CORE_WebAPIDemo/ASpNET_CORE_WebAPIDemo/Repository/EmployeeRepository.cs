﻿using ASpNET_CORE_WebAPIDemo.Models;
using ASpNET_CORE_WebAPIDemo.Services;
using ASpNET_CORE_WebAPIDemo.ViewModels;
using System.Collections.Generic;
using System.Linq;

namespace ASpNET_CORE_WebAPIDemo.Repository
{
    public class EmployeeRepository : IEmployeeService
    {
        //Step 1
        private EmpContext _empContext;
        //Step 2
        public EmployeeRepository(EmpContext empContext)
        {
            _empContext = empContext;
        }

        ResponseModel IEmployeeService.DeleteEmployee(int id)
        {
            throw new System.NotImplementedException();
        }

        Employee IEmployeeService.GetEmployee(int id)
        {
            Employee employee = null;
            try
            {
                employee = _empContext.Find<Employee>(id);
            }
            catch (System.Exception)
            {

                throw;
            }
            return employee;
        }

        List<Employee> IEmployeeService.GetEmployeesList()
        {
            List<Employee> empList;
            try
            {
                empList = _empContext.Set<Employee>().ToList();
            }
            catch (System.Exception)
            {

                throw;
            }
            return empList;
        }

        ResponseModel IEmployeeService.SaveEmployee(Employee employeeModel)
        {
            throw new System.NotImplementedException();
        }
    }
}
