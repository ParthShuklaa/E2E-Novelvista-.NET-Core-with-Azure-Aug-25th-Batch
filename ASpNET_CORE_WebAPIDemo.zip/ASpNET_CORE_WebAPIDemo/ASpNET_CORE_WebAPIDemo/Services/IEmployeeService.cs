﻿using ASpNET_CORE_WebAPIDemo.Models;
using ASpNET_CORE_WebAPIDemo.ViewModels;
using System.Collections.Generic;

namespace ASpNET_CORE_WebAPIDemo.Services
{
    public interface IEmployeeService
    {
        List<Employee> GetEmployeesList();
        Employee GetEmployee(int id);
        ResponseModel SaveEmployee(Employee employeeModel);
        ResponseModel DeleteEmployee(int id);
    }
}
