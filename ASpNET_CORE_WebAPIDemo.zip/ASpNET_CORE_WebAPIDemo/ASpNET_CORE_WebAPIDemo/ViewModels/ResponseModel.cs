﻿namespace ASpNET_CORE_WebAPIDemo.ViewModels
{
    public class ResponseModel
    {
        public bool IsSuccess
        {
            get; set;
        }

        public string Message { get; set; }
    }
}
