﻿using Members.Data.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Members.Data.Model;
using Members.Data.Interface;
using System.Collections.Generic;

namespace Demo_EMPData_BackEND.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MemberController : ControllerBase
    {
        private IMembers members = new MembersRepository();

        [HttpGet]
        public ActionResult<IEnumerable<Member>> GetAllMembers()
        {
            return members.GetAllMemeber();
        }
            public ActionResult<Member> GetMemberById( int id)
        {
            return members.GetMember(id);
        }
    }
}
