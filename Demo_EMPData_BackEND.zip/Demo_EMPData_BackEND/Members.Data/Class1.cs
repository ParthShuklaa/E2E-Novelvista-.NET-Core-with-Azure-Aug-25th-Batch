﻿using System;

namespace Members.Data
{
    public class Class1
    {
    }
}
