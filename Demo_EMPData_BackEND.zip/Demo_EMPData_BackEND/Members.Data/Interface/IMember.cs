﻿using System;
using System.Collections.Generic;
using System.Text;
using Members.Data.Model;

namespace Members.Data.Interface
{
    public interface IMembers
    {
        List<Member> GetAllMemeber();
        Member GetMember(int id);
    }
}
