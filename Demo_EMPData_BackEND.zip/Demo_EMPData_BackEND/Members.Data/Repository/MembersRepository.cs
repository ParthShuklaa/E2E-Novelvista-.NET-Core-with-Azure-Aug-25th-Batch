﻿using Members.Data.Interface;
using Members.Data.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Members.Data.Repository
{
    public class MembersRepository : IMembers
    {
        List<Member> listMembers = new List<Member> {
                new Member { MemeberId = 1, FirstName = "Raj", LastName = " Sharma", Address = "Gujrat" },
                new Member { MemeberId = 1, FirstName = "Rajesh", LastName = "Varma", Address = "Maharashtra" },
                new Member { MemeberId = 1, FirstName = "Rajiv", LastName = " Singh", Address = "Delhi" },
                new Member { MemeberId = 1, FirstName = "Rajnesh", LastName = " Sharma", Address = "Maharashtra" },
                new Member { MemeberId = 1, FirstName = "Rajendra", LastName = " Sharma", Address = "Gujrat" },
                new Member { MemeberId = 1, FirstName = "Rajkumar", LastName = " Sharma", Address = "Delhi" },

            };
        List<Member> IMembers.GetAllMemeber()
        {
            return listMembers;
        }
        Member IMembers.GetMember(int id)
        {
            return listMembers.FirstOrDefault(x => x.MemeberId == id);
        }
    }
}
